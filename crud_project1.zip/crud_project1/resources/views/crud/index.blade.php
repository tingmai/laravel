<!DOCTYPE html>
<html lang="en">
<head>
  <title> CRUD </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

	<div class="container">
		<div class="jumbotron"> <h1> Northern City </h1> </div>
	</div>
	<div class="container" style="margin-bottom: 20px;">

		<a href="{{route('crud.create')}}" class="btn btn-primary"> Add New Product </a>
	</div>

	<div class="container">
		<table class="table table-striped">
			<thead>
				<tr>
					<td> ID </td>
					<td> Name </td>
					<td> Price </td>
					<td> Photo </td>
					<td> Action </td>
				</tr>
			</thead>
			<tbody>
				@foreach($products as $product)


					<tr>
						<td> {{$product->id}} </td>
						<td> {{$product->name}} </td>
						<td> {{$product->price}} </td>
						<td> <img src="{{asset('images')}}/{{$product->photo}}" class="img-thumbnail" style="width:100px;height: 100px;"> </td>
						<td> 
								<a href="{{route('crud.show',$product->id)}}" class="btn btn-primary"> Details </a>
								<a href="#" class="btn btn-warning"> Edit </a>
								<a href="#" class="btn btn-danger"> Delete </a>
						 </td>
					</tr>


				@endforeach
			</tbody>
		</table>
	</div>

</body>
</html>